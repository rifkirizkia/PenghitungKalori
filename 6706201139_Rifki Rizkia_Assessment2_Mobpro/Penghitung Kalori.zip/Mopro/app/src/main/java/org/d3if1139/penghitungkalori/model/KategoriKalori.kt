package org.d3if1139.penghitungkalori.model

enum class KategoriKalori {
    SEDIKIT, SEDANG, BANYAK
}