package org.d3if1139.penghitungkalori.model

data class UserInput(
    val tinggi: Double,
    val berat: Double,
    val gender: String,
    val usia: Int
)
