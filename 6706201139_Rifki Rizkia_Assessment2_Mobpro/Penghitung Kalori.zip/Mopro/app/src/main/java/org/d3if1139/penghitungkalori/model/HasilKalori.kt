package org.d3if1139.penghitungkalori.model

data class HasilKalori(
    val kalori: Double,
    val kategori: KategoriKalori
)
